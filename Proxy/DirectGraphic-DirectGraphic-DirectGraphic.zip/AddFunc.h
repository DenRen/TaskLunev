#pragma once

#include <windows.h>

#define SET_IN_ZERO(mem) ZeroMemory (&(mem), sizeof (mem))